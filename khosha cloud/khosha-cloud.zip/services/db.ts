import { createClient } from "@libsql/client";
import { AGENTS, PROJECTS, TASKS, TIMELINE } from "../constants";

const URL = "https://kms-khoshasystems.aws-ap-south-1.turso.io";
const TOKEN = "eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.eyJhIjoicnciLCJpYXQiOjE3NzA3Mjg1MzksImlkIjoiMTM0MWZlMGYtYzUyNy00NTAyLTk3MzUtNmM1ZTQ1MWU0OThkIiwicmlkIjoiYjVhNTZjNjQtZDA1MS00Y2FiLWIzMDktNjRkN2RlZjMwZTE3In0.sStEsiaTfhtLF76CG5R4eE-5eEcUjWAwH4IlWXay7iz3pr3zN4zyW722ibvQItnXJJndM_GuW_qEcdS-mlrtBw";

export const db = createClient({
  url: URL,
  authToken: TOKEN,
});

export const initDB = async () => {
  try {
    console.log("Initializing Khosha Cloud Database...");
    
    // Correct Drop Order: Dependents first (Timeline -> Tasks -> Projects -> Agents)
    // This prevents Foreign Key Constraint errors which block table deletion
    await db.batch([
      "DROP TABLE IF EXISTS timeline",
      "DROP TABLE IF EXISTS tasks",
      "DROP TABLE IF EXISTS projects",
      "DROP TABLE IF EXISTS agents",
    ]);

    // Create Tables with explicit schema
    await db.batch([
      `CREATE TABLE IF NOT EXISTS agents (
        id TEXT PRIMARY KEY,
        name TEXT,
        role TEXT,
        status TEXT,
        avatar TEXT,
        skills TEXT,
        current_task_id TEXT
      )`,
      `CREATE TABLE IF NOT EXISTS projects (
        id TEXT PRIMARY KEY,
        title TEXT,
        description TEXT,
        deadline TEXT,
        status TEXT,
        progress INTEGER,
        tasks_ids TEXT,
        lead_agent_id TEXT,
        budget TEXT
      )`,
      `CREATE TABLE IF NOT EXISTS tasks (
        id TEXT PRIMARY KEY,
        title TEXT,
        description TEXT,
        status TEXT,
        priority TEXT,
        project_id TEXT,
        assigned_agent_id TEXT,
        deadline TEXT,
        comments TEXT,
        progress INTEGER
      )`,
      `CREATE TABLE IF NOT EXISTS timeline (
        id TEXT PRIMARY KEY,
        agent_id TEXT,
        type TEXT,
        description TEXT,
        timestamp TEXT,
        related_task_id TEXT
      )`
    ]);

    console.log("Tables created. Seeding data...");
    
    // Seed Agents
    const agentInserts = AGENTS.map(a => ({
      sql: "INSERT INTO agents (id, name, role, status, avatar, skills, current_task_id) VALUES (?, ?, ?, ?, ?, ?, ?)",
      args: [a.id, a.name, a.role, a.status, a.avatar, JSON.stringify(a.skills), a.currentTaskId || null]
    }));

    // Seed Projects
    const projectInserts = PROJECTS.map(p => ({
      sql: "INSERT INTO projects (id, title, description, deadline, status, progress, tasks_ids, lead_agent_id, budget) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
      args: [p.id, p.title, p.description, p.deadline, p.status, p.progress, JSON.stringify(p.tasksIds), p.leadAgentId, p.budget]
    }));

    // Seed Tasks
    const taskInserts = TASKS.map(t => ({
      sql: "INSERT INTO tasks (id, title, description, status, priority, project_id, assigned_agent_id, deadline, comments, progress) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
      args: [t.id, t.title, t.description, t.status, t.priority, t.projectId, t.assignedAgentId || null, t.deadline, JSON.stringify(t.comments), t.progress]
    }));

    // Seed Timeline
    const timelineInserts = TIMELINE.map(t => ({
      sql: "INSERT INTO timeline (id, agent_id, type, description, timestamp, related_task_id) VALUES (?, ?, ?, ?, ?, ?)",
      args: [t.id, t.agentId, t.type, t.description, t.timestamp, t.relatedTaskId || null]
    }));

    // Execute inserts in separate batches to avoid size limits
    if (agentInserts.length) await db.batch(agentInserts);
    if (projectInserts.length) await db.batch(projectInserts);
    if (taskInserts.length) await db.batch(taskInserts);
    if (timelineInserts.length) await db.batch(timelineInserts);
    
    console.log("Database seeded successfully.");
    
  } catch (error) {
    console.error("Database initialization failed:", error);
    throw error;
  }
};

export const fetchData = async () => {
  try {
    // Select specific columns to ensure we get exactly what we expect
    const [agentsRs, projectsRs, tasksRs, timelineRs] = await Promise.all([
      db.execute("SELECT id, name, role, status, avatar, skills, current_task_id FROM agents"),
      db.execute("SELECT id, title, description, deadline, status, progress, tasks_ids, lead_agent_id, budget FROM projects"),
      db.execute("SELECT id, title, description, status, priority, project_id, assigned_agent_id, deadline, comments, progress FROM tasks"),
      db.execute("SELECT id, agent_id, type, description, timestamp, related_task_id FROM timeline ORDER BY timestamp DESC")
    ]);

    const safeJSONParse = (str: any, fallback: any) => {
      if (!str || str === 'null' || str === 'undefined') return fallback;
      try {
        if (typeof str === 'object') return str;
        return JSON.parse(str);
      } catch (e) {
        console.warn("JSON Parse Error for value:", str);
        return fallback;
      }
    };

    return {
      agents: agentsRs.rows.map((r: any) => ({
        id: r.id,
        name: r.name,
        role: r.role,
        status: r.status,
        avatar: r.avatar,
        skills: safeJSONParse(r.skills, []),
        currentTaskId: r.current_task_id
      })),
      projects: projectsRs.rows.map((r: any) => ({
        id: r.id,
        title: r.title,
        description: r.description,
        deadline: r.deadline,
        status: r.status,
        progress: r.progress,
        tasksIds: safeJSONParse(r.tasks_ids, []),
        leadAgentId: r.lead_agent_id,
        budget: r.budget
      })),
      tasks: tasksRs.rows.map((r: any) => ({
        id: r.id,
        title: r.title,
        description: r.description,
        status: r.status,
        priority: r.priority,
        projectId: r.project_id,
        assignedAgentId: r.assigned_agent_id,
        deadline: r.deadline,
        comments: safeJSONParse(r.comments, []),
        progress: r.progress
      })),
      timeline: timelineRs.rows.map((r: any) => ({
        id: r.id,
        agentId: r.agent_id,
        type: r.type,
        description: r.description,
        timestamp: r.timestamp,
        relatedTaskId: r.related_task_id
      }))
    };
  } catch (e) {
    console.error("Error fetching data from Turso:", e);
    return null;
  }
};