import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || '';

// Initialize only if key exists to avoid runtime crashes in dev if missing
const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

export const generateAIReport = async (contextType: 'project' | 'agent' | 'task', data: any): Promise<string> => {
  if (!ai) {
    return "API Key not configured. Unable to generate AI report.";
  }

  try {
    const model = 'gemini-3-flash-preview';
    let prompt = "";

    if (contextType === 'project') {
      prompt = `You are a Senior Technical Project Manager. Analyze the following project data and provide a concise status report (max 100 words). Focus on progress, risks, and next steps. Data: ${JSON.stringify(data)}`;
    } else if (contextType === 'agent') {
      prompt = `You are an HR & Engineering Manager. Analyze this agent's profile and current workload. Provide a brief performance summary (max 100 words) and efficiency rating. Data: ${JSON.stringify(data)}`;
    } else {
      prompt = `You are a Lead Developer. Analyze this task and its comments. Summarize the current blocker or status and suggest the best next action (max 80 words). Data: ${JSON.stringify(data)}`;
    }

    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
    });

    return response.text || "No insights available.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Failed to generate AI report. Please try again later.";
  }
};
