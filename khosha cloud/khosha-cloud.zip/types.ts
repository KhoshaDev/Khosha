export enum AgentStatus {
  ONLINE = 'ONLINE',
  OFFLINE = 'OFFLINE',
  BUSY = 'BUSY',
  IDLE = 'IDLE'
}

export enum TaskStatus {
  TODO = 'TODO',
  IN_PROGRESS = 'IN_PROGRESS',
  REVIEW = 'REVIEW',
  DONE = 'DONE'
}

export enum Priority {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH',
  CRITICAL = 'CRITICAL'
}

export interface Agent {
  id: string;
  name: string;
  role: string;
  status: AgentStatus;
  avatar: string;
  skills: string[];
  currentTaskId?: string;
}

export interface Comment {
  id: string;
  author: string;
  text: string;
  timestamp: string;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  status: TaskStatus;
  priority: Priority;
  projectId: string;
  assignedAgentId?: string;
  deadline: string;
  comments: Comment[];
  progress: number; // 0-100
}

export interface Project {
  id: string;
  title: string;
  description: string;
  deadline: string;
  status: 'ACTIVE' | 'COMPLETED' | 'ON_HOLD';
  progress: number; // 0-100
  tasksIds: string[];
  leadAgentId?: string;
  budget: string;
}

export interface TimelineEvent {
  id: string;
  agentId: string;
  type: 'COMMIT' | 'COMMENT' | 'STATUS_CHANGE' | 'TASK_COMPLETE';
  description: string;
  timestamp: string;
  relatedTaskId?: string;
}

export type View = 'PROJECTS' | 'TASKS' | 'AGENTS';
