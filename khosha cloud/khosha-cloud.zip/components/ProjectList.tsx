import React from 'react';
import { Project } from '../types';
import { ChevronRight, Calendar, DollarSign, Activity } from 'lucide-react';
import { Badge } from './ui/Badge';

interface ProjectListProps {
  projects: Project[];
  onSelect: (project: Project) => void;
}

export const ProjectList: React.FC<ProjectListProps> = ({ projects, onSelect }) => {
  return (
    <div className="space-y-4 pb-20">
      {projects.map((project) => (
        <div 
          key={project.id}
          onClick={() => onSelect(project)}
          className="group relative bg-white border border-slate-100 rounded-2xl p-5 shadow-soft hover:shadow-soft-lg active:scale-[0.99] transition-all cursor-pointer overflow-hidden"
        >
          {/* Animated Mesh Gradient background for active projects */}
          {project.status === 'ACTIVE' && (
             <div className="absolute inset-0 bg-gradient-to-r from-transparent via-slate-50/50 to-transparent translate-x-[-100%] group-hover:animate-[shimmer_2s_infinite]"></div>
          )}

          <div className="relative z-10">
            <div className="flex justify-between items-start mb-2">
              <div className="flex items-center gap-2">
                 {project.status === 'ACTIVE' && (
                    <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                 )}
                 <h3 className="text-slate-900 font-bold text-lg leading-tight tracking-tight">{project.title}</h3>
              </div>
              <Badge variant={project.status === 'ACTIVE' ? 'success' : project.status === 'ON_HOLD' ? 'warning' : 'default'}>
                {project.status.replace('_', ' ')}
              </Badge>
            </div>

            <p className="text-slate-500 text-sm line-clamp-2 mb-4 font-medium leading-relaxed">
              {project.description}
            </p>
            
            <div className="flex items-center text-slate-400 text-xs gap-4 mb-4 font-mono">
                <span className="flex items-center gap-1.5"><Calendar size={14} className="text-primary-500" /> {project.deadline}</span>
                <span className="flex items-center gap-1.5"><DollarSign size={14} className="text-emerald-500" /> {project.budget}</span>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-xs font-semibold text-slate-500">
                <span>Completion Status</span>
                <span className="text-slate-900 font-mono">{project.progress}%</span>
              </div>
              <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                <div 
                  className={`h-full rounded-full transition-all duration-700 ease-out shadow-[0_0_10px_rgba(15,23,42,0.1)] ${project.status === 'ACTIVE' ? 'bg-gradient-to-r from-primary-600 to-indigo-500' : 'bg-slate-400'}`}
                  style={{ width: `${project.progress}%` }}
                />
              </div>
            </div>
            
            {project.status === 'ACTIVE' && (
               <div className="mt-4 pt-3 border-t border-slate-50 flex items-center gap-2 text-[10px] text-slate-400 uppercase font-bold tracking-wider">
                 <Activity size={12} className="text-primary-500" />
                 Processing Task Queue...
               </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
};