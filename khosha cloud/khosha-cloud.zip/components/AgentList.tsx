import React from 'react';
import { Agent, AgentStatus } from '../types';
import { Cpu, Wifi, UserX, Activity } from 'lucide-react';

interface AgentListProps {
  agents: Agent[];
  onSelect: (agent: Agent) => void;
}

export const AgentList: React.FC<AgentListProps> = ({ agents, onSelect }) => {
  // Handle empty state gracefully
  if (!agents || agents.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-slate-400 border border-dashed border-slate-200 rounded-2xl bg-slate-50/50">
        <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mb-4 shadow-sm">
          <UserX size={32} className="text-slate-400" />
        </div>
        <p className="text-sm font-bold text-slate-600">No Agents Detected</p>
        <p className="text-xs text-slate-400 mt-1 max-w-[200px] text-center">
          The neural link is active but no personnel data was found in the local cluster.
        </p>
      </div>
    );
  }

  const getStatusColor = (status: AgentStatus) => {
    switch (status) {
      case AgentStatus.ONLINE: return 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]';
      case AgentStatus.BUSY: return 'bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.5)]';
      case AgentStatus.OFFLINE: return 'bg-slate-400';
      case AgentStatus.IDLE: return 'bg-blue-400';
      default: return 'bg-slate-400';
    }
  };

  return (
    <div className="grid grid-cols-2 gap-4 pb-20">
      {agents.map((agent) => (
        <div 
          key={agent.id}
          onClick={() => onSelect(agent)}
          className="relative flex flex-col items-center p-5 bg-white border border-slate-100 rounded-2xl shadow-soft hover:shadow-soft-lg active:scale-95 transition-all cursor-pointer group overflow-hidden"
        >
          {/* Busy animation overlay */}
          {agent.status === AgentStatus.BUSY && (
             <div className="absolute top-0 left-0 w-full h-1 bg-amber-500 animate-[progressIndeterminate_2s_infinite_linear]"></div>
          )}

          <div className="relative mb-4">
            <img 
              src={agent.avatar} 
              alt={agent.name} 
              className="w-16 h-16 rounded-2xl object-cover ring-4 ring-slate-50 bg-slate-100"
            />
            <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white ${getStatusColor(agent.status)}`} />
            
            {agent.status === AgentStatus.ONLINE && (
               <div className="absolute -top-1 -right-1 bg-emerald-100 rounded-full p-1 border-2 border-white">
                 <Wifi size={10} className="text-emerald-600" />
               </div>
            )}
          </div>
          
          <h3 className="text-slate-900 font-bold text-center text-sm truncate w-full tracking-tight">{agent.name}</h3>
          <p className="text-primary-600 text-xs font-semibold text-center mb-4 truncate w-full uppercase tracking-wide">{agent.role}</p>
          
          {agent.status === AgentStatus.BUSY ? (
             <div className="w-full bg-amber-50 border border-amber-100 rounded-lg p-2 flex items-center justify-center gap-2 mb-2">
                <Activity size={12} className="text-amber-500 animate-spin" />
                <span className="text-[10px] font-bold text-amber-600 uppercase tracking-wider">Processing</span>
             </div>
          ) : (
             <div className="flex flex-wrap gap-1.5 justify-center w-full min-h-[28px]">
               {agent.skills && Array.isArray(agent.skills) ? agent.skills.slice(0, 2).map(skill => (
                  <span key={skill} className="px-2 py-1 bg-slate-50 border border-slate-100 rounded-md text-[10px] font-medium text-slate-500 w-full text-center truncate">
                    {skill}
                  </span>
               )) : (
                 <span className="text-[10px] text-slate-300 italic">No skills listed</span>
               )}
             </div>
          )}
        </div>
      ))}
    </div>
  );
};