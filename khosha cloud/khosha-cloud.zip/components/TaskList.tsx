import React from 'react';
import { Task, Priority, TaskStatus } from '../types';
import { CheckCircle2, Circle, Clock, Loader2 } from 'lucide-react';

interface TaskListProps {
  tasks: Task[];
  onSelect: (task: Task) => void;
}

export const TaskList: React.FC<TaskListProps> = ({ tasks, onSelect }) => {
  
  const getPriorityColor = (p: Priority) => {
    switch (p) {
      case Priority.CRITICAL: return 'text-rose-500 bg-rose-50 border-rose-100';
      case Priority.HIGH: return 'text-amber-500 bg-amber-50 border-amber-100';
      case Priority.MEDIUM: return 'text-blue-500 bg-blue-50 border-blue-100';
      default: return 'text-slate-500 bg-slate-50 border-slate-100';
    }
  };

  const getStatusIcon = (s: TaskStatus) => {
    if (s === TaskStatus.DONE) return <CheckCircle2 className="text-emerald-500" size={20} />;
    if (s === TaskStatus.IN_PROGRESS) return <Loader2 className="text-blue-500 animate-spin" size={20} />;
    if (s === TaskStatus.REVIEW) return <Clock className="text-amber-500" size={20} />;
    return <Circle className="text-slate-300" size={20} />;
  };

  return (
    <div className="space-y-3 pb-20">
      {tasks.map((task) => (
        <div 
          key={task.id}
          onClick={() => onSelect(task)}
          className="group relative flex items-center gap-4 p-4 bg-white border border-slate-100 rounded-xl shadow-soft hover:shadow-soft-lg hover:border-primary-100 active:bg-slate-50 transition-all cursor-pointer overflow-hidden"
        >
          {/* Active progress strip background */}
          {task.status === 'IN_PROGRESS' && (
             <div className="absolute bottom-0 left-0 h-[2px] bg-primary-500 transition-all duration-1000" style={{ width: `${task.progress}%` }}></div>
          )}

          <div className="shrink-0 transition-transform group-hover:scale-110">
            {getStatusIcon(task.status)}
          </div>
          
          <div className="flex-1 min-w-0">
            <h4 className={`text-sm font-semibold truncate ${task.status === TaskStatus.DONE ? 'text-slate-400 line-through' : 'text-slate-900'}`}>
              {task.title}
            </h4>
            <div className="flex items-center gap-2 mt-1.5">
              <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider border ${getPriorityColor(task.priority)}`}>
                {task.priority}
              </span>
              <span className="text-slate-300 text-[10px]">•</span>
              <span className="text-xs text-slate-500 truncate font-mono">{task.projectId}</span>
            </div>
          </div>

          <div className="shrink-0 flex items-center gap-2">
             {task.status === 'IN_PROGRESS' && (
               <span className="text-[10px] font-mono text-primary-500 hidden sm:block">Writing...</span>
             )}
             <div className={`w-2 h-2 rounded-full ring-2 ring-white shadow-sm ${task.assignedAgentId ? 'bg-emerald-500' : 'bg-slate-200'} ${task.status === 'IN_PROGRESS' ? 'animate-pulse' : ''}`} />
          </div>
        </div>
      ))}
    </div>
  );
};