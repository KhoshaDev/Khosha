import { Agent, AgentStatus, Project, Task, TaskStatus, Priority, TimelineEvent } from './types';

// Mock Agents
export const AGENTS: Agent[] = [
  {
    id: 'a1',
    name: 'Atlas Prime',
    role: 'Lead Architect',
    status: AgentStatus.ONLINE,
    avatar: 'https://picsum.photos/seed/atlas/100/100',
    skills: ['System Design', 'React', 'Node.js'],
    currentTaskId: 't1'
  },
  {
    id: 'a2',
    name: 'Nova Scout',
    role: 'Frontend Specialist',
    status: AgentStatus.BUSY,
    avatar: 'https://picsum.photos/seed/nova/100/100',
    skills: ['Tailwind', 'UI/UX', 'Animation'],
    currentTaskId: 't2'
  },
  {
    id: 'a3',
    name: 'Vector Core',
    role: 'Backend Engineer',
    status: AgentStatus.IDLE,
    avatar: 'https://picsum.photos/seed/vector/100/100',
    skills: ['Python', 'SQL', 'Docker'],
  },
  {
    id: 'a4',
    name: 'Cipher Ghost',
    role: 'Security Analyst',
    status: AgentStatus.OFFLINE,
    avatar: 'https://picsum.photos/seed/cipher/100/100',
    skills: ['Penetration Testing', 'Cryptography'],
  },
  {
    id: 'a5',
    name: 'Echo Unit',
    role: 'QA Automation',
    status: AgentStatus.ONLINE,
    avatar: 'https://picsum.photos/seed/echo/100/100',
    skills: ['Cypress', 'Jest', 'CI/CD'],
    currentTaskId: 't5'
  }
];

// Mock Projects
export const PROJECTS: Project[] = [
  {
    id: 'p1',
    title: 'Project Nebula',
    description: 'Next-generation cloud infrastructure scaling solution using autonomous orchestration.',
    deadline: '2024-12-01',
    status: 'ACTIVE',
    progress: 75,
    tasksIds: ['t1', 't2', 't3'],
    leadAgentId: 'a1',
    budget: '$120,000'
  },
  {
    id: 'p2',
    title: 'Quantum UI Kit',
    description: 'A comprehensive React component library optimized for high-performance dashboards.',
    deadline: '2024-10-15',
    status: 'ACTIVE',
    progress: 30,
    tasksIds: ['t4', 't5', 't6'],
    leadAgentId: 'a2',
    budget: '$45,000'
  },
  {
    id: 'p3',
    title: 'Stealth Protocol',
    description: 'Encrypted messaging layer for inter-agent communication.',
    deadline: '2025-01-20',
    status: 'ON_HOLD',
    progress: 10,
    tasksIds: [],
    leadAgentId: 'a4',
    budget: '$80,000'
  }
];

// Mock Tasks
export const TASKS: Task[] = [
  {
    id: 't1',
    title: 'Design API Gateway',
    description: 'Create the initial schema for the unified API gateway handling 1M+ req/s.',
    status: TaskStatus.IN_PROGRESS,
    priority: Priority.CRITICAL,
    projectId: 'p1',
    assignedAgentId: 'a1',
    deadline: '2024-11-05',
    progress: 60,
    comments: [
      { id: 'c1', author: 'Atlas Prime', text: 'Draft schema completed. Reviewing edge cases.', timestamp: '2h ago' },
      { id: 'c2', author: 'Vector Core', text: 'Check the rate limiting specs.', timestamp: '1h ago' }
    ]
  },
  {
    id: 't2',
    title: 'Implement Dark Mode',
    description: 'Add system-wide dark mode support using Tailwind CSS variables.',
    status: TaskStatus.IN_PROGRESS,
    priority: Priority.MEDIUM,
    projectId: 'p2',
    assignedAgentId: 'a2',
    deadline: '2024-10-10',
    progress: 45,
    comments: []
  },
  {
    id: 't3',
    title: 'Database Migration',
    description: 'Migrate legacy SQL data to the new distributed NoSQL cluster.',
    status: TaskStatus.TODO,
    priority: Priority.HIGH,
    projectId: 'p1',
    assignedAgentId: 'a3',
    deadline: '2024-11-20',
    progress: 0,
    comments: []
  },
  {
    id: 't4',
    title: 'Component Docs',
    description: 'Write comprehensive documentation for the button and input components.',
    status: TaskStatus.REVIEW,
    priority: Priority.LOW,
    projectId: 'p2',
    assignedAgentId: 'a5',
    deadline: '2024-10-12',
    progress: 90,
    comments: [
      { id: 'c3', author: 'Echo Unit', text: 'Docs are ready for final sign-off.', timestamp: '30m ago' }
    ]
  },
  {
    id: 't5',
    title: 'Unit Test Coverage',
    description: 'Increase core library test coverage to 95%.',
    status: TaskStatus.IN_PROGRESS,
    priority: Priority.HIGH,
    projectId: 'p2',
    assignedAgentId: 'a5',
    deadline: '2024-10-18',
    progress: 20,
    comments: []
  },
    {
    id: 't6',
    title: 'Accessibility Audit',
    description: 'Run full WCAG 2.1 audit on all public facing pages.',
    status: TaskStatus.TODO,
    priority: Priority.MEDIUM,
    projectId: 'p2',
    assignedAgentId: 'a2',
    deadline: '2024-10-25',
    progress: 0,
    comments: []
  }
];

// Mock Timeline
export const TIMELINE: TimelineEvent[] = [
  { id: 'e1', agentId: 'a1', type: 'COMMIT', description: 'Pushed initial commit for Nebula core', timestamp: '2024-10-01 09:00' },
  { id: 'e2', agentId: 'a2', type: 'STATUS_CHANGE', description: 'Changed status to BUSY', timestamp: '2024-10-01 10:15' },
  { id: 'e3', agentId: 'a1', type: 'COMMENT', description: 'Commented on "API Gateway Design"', timestamp: '2024-10-01 11:30', relatedTaskId: 't1' },
  { id: 'e4', agentId: 'a5', type: 'TASK_COMPLETE', description: 'Completed "Setup CI Pipeline"', timestamp: '2024-10-02 14:20' },
  { id: 'e5', agentId: 'a2', type: 'COMMIT', description: 'Refactored button component styles', timestamp: '2024-10-02 16:45' },
];
