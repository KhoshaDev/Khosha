import React, { useState, useEffect, useRef } from 'react';
import { Project, Task, Agent, TimelineEvent, View } from './types';
import { ProjectList } from './components/ProjectList';
import { TaskList } from './components/TaskList';
import { AgentList } from './components/AgentList';
import { Modal } from './components/ui/Modal';
import { Badge } from './components/ui/Badge';
import { LayoutGrid, CheckSquare, Users, Cpu, Activity, Send, Command, Zap, Terminal, FileText, Download, Eye, RefreshCw, Database } from 'lucide-react';
import { generateAIReport } from './services/geminiService';
import { initDB, fetchData } from './services/db';

const SYSTEM_LOGS = [
  "Optimizing query execution plans...",
  "Allocating GPU cluster node #4...",
  "Syncing neural weights...",
  "Garbage collection active...",
  "Verifying integrity checksums...",
  "Deploying microservice v2.1...",
  "Analyzing semantic tokens..."
];

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>('PROJECTS');
  
  // Data State
  const [projects, setProjects] = useState<Project[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [agents, setAgents] = useState<Agent[]>([]);
  const [timeline, setTimeline] = useState<TimelineEvent[]>([]);
  const [loading, setLoading] = useState(true);

  // Simulated Live State
  const [systemLogs, setSystemLogs] = useState<string[]>([]);
  const [cpuUsage, setCpuUsage] = useState(12);
  const [memoryUsage, setMemoryUsage] = useState(24);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Selection State
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [selectedAgent, setSelectedAgent] = useState<Agent | null>(null);

  // AI State
  const [aiLoading, setAiLoading] = useState(false);
  const [aiReport, setAiReport] = useState<string | null>(null);

  // Initial Load
  useEffect(() => {
    const bootstrap = async () => {
      try {
        await initDB(); // Try to seed first
      } catch (e) {
        console.error("Bootstrapping failed", e);
      }
      await refreshData();
      setLoading(false);
    };
    bootstrap();
  }, []);

  // Live Simulation Engine
  useEffect(() => {
    const interval = setInterval(() => {
      // Fluctuate metrics
      setCpuUsage(prev => Math.min(100, Math.max(5, prev + (Math.random() * 10 - 5))));
      setMemoryUsage(prev => Math.min(100, Math.max(10, prev + (Math.random() * 5 - 2))));

      // Add random system log
      if (Math.random() > 0.7) {
        const newLog = SYSTEM_LOGS[Math.floor(Math.random() * SYSTEM_LOGS.length)];
        setSystemLogs(prev => [newLog, ...prev].slice(0, 5));
      }

      // Auto-refresh data periodically
      if (Math.random() > 0.95) {
        refreshData(true);
      }

    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const refreshData = async (silent = false) => {
    if (!silent) setIsRefreshing(true);
    const data = await fetchData();
    if (data) {
      setProjects(data.projects as Project[]);
      setTasks(data.tasks as Task[]);
      setAgents(data.agents as Agent[]);
      setTimeline(data.timeline as TimelineEvent[]);
    }
    if (!silent) setTimeout(() => setIsRefreshing(false), 800);
  };

  const handleManualReset = async () => {
    if(confirm("Force reset database? This will clear all changes and reload default data.")) {
      setLoading(true);
      await initDB();
      await refreshData();
      setLoading(false);
    }
  };

  const handleGenerateReport = async (type: 'project' | 'agent' | 'task', data: any) => {
    setAiLoading(true);
    setAiReport(null);
    const report = await generateAIReport(type, data);
    setAiReport(report);
    setAiLoading(false);
  };

  const closeModal = () => {
    setSelectedProject(null);
    setSelectedTask(null);
    setSelectedAgent(null);
    setAiReport(null);
  };

  // Derived Data Helpers
  const getAgentName = (id?: string) => agents.find(a => a.id === id)?.name || 'Unassigned';
  const getProjectName = (id: string) => projects.find(p => p.id === id)?.title || 'Unknown Project';

  // Mock File Artifact Generator
  const getArtifactsForTask = (task: Task) => {
    const isCode = task.title.toLowerCase().includes('api') || task.title.toLowerCase().includes('migration');
    const isDesign = task.title.toLowerCase().includes('design') || task.title.toLowerCase().includes('ui');
    
    return [
      { name: isCode ? 'module_export.ts' : (isDesign ? 'mockup_v2.fig' : 'document.pdf'), size: '2.4 MB', type: isCode ? 'CODE' : 'ASSET' },
      { name: 'audit_log.json', size: '12 KB', type: 'LOG' }
    ];
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
        <div className="w-16 h-16 rounded-2xl bg-slate-900 flex items-center justify-center shadow-glow animate-pulse relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-tr from-primary-500/20 to-transparent"></div>
          <Cpu className="text-white relative z-10" size={32} />
        </div>
        <h2 className="mt-6 text-slate-900 font-bold tracking-tight text-lg">Booting Khosha Cloud</h2>
        <div className="mt-2 w-48 h-1 bg-slate-200 rounded-full overflow-hidden">
          <div className="h-full bg-primary-600 animate-progress-indeterminate"></div>
        </div>
        <p className="text-slate-400 text-xs mt-3 font-mono">Initializing Neural Handshake...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans selection:bg-primary-100 pb-28">
      
      {/* HUD Header */}
      <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-xl border-b border-slate-200 shadow-sm transition-all duration-300">
        <div className="px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center shadow-lg shadow-slate-900/10 border border-slate-800 relative group cursor-pointer" onClick={() => refreshData()}>
              <Command className={`text-white transition-transform duration-700 ${isRefreshing ? 'rotate-180' : ''}`} size={20} />
              <div className="absolute inset-0 rounded-xl border border-white/10"></div>
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight text-slate-900 leading-none">Khosha Cloud</h1>
              <div className="flex items-center gap-2 mt-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                <span className="text-[10px] font-mono font-medium text-slate-500 uppercase tracking-widest">Live Connection</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
             {/* Reset Button (Hidden feature) */}
             <button onClick={handleManualReset} className="p-2 text-slate-300 hover:text-red-600 hover:bg-red-50 rounded-full transition-all" title="Reset Database">
               <Database size={16} />
             </button>

            {/* Mini System Monitor */}
            <div className="hidden sm:flex items-center gap-3 pr-4 border-r border-slate-200">
              <div className="flex flex-col items-end">
                <span className="text-[9px] text-slate-400 uppercase font-bold tracking-wider">CPU</span>
                <div className="flex items-end gap-1 h-3">
                   {[1,2,3,4,5].map(i => (
                     <div key={i} className={`w-1 rounded-t-sm transition-all duration-300 ${i * 20 < cpuUsage ? 'bg-primary-500 h-full' : 'bg-slate-200 h-1/3'}`}></div>
                   ))}
                </div>
              </div>
              <div className="flex flex-col items-end">
                <span className="text-[9px] text-slate-400 uppercase font-bold tracking-wider">RAM</span>
                 <div className="w-12 h-1 bg-slate-200 rounded-full mt-1 overflow-hidden">
                   <div className="h-full bg-indigo-500 transition-all duration-500" style={{ width: `${memoryUsage}%` }}></div>
                 </div>
              </div>
            </div>
             <button onClick={() => refreshData()} className="p-2 text-slate-400 hover:text-primary-600 hover:bg-primary-50 rounded-full transition-all active:scale-95">
               <RefreshCw size={18} className={isRefreshing ? 'animate-spin' : ''} />
             </button>
          </div>
        </div>
        
        {/* System Ticker Line */}
        <div className="bg-slate-900 text-white/80 overflow-hidden py-1 flex items-center relative">
          <div className="absolute left-0 top-0 bottom-0 w-8 bg-gradient-to-r from-slate-900 to-transparent z-10"></div>
          <div className="absolute right-0 top-0 bottom-0 w-8 bg-gradient-to-l from-slate-900 to-transparent z-10"></div>
          <div className="whitespace-nowrap flex items-center gap-8 animate-marquee text-[10px] font-mono tracking-wide px-4">
             {systemLogs.map((log, i) => (
               <span key={i} className="flex items-center gap-2">
                 <span className="text-primary-400">➜</span> {log}
               </span>
             ))}
             {timeline.slice(0, 3).map((t, i) => (
                <span key={`t-${i}`} className="flex items-center gap-2 opacity-70">
                  <span className="text-emerald-400">●</span> {t.description}
                </span>
             ))}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-3xl mx-auto px-4 py-6">
        
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-slate-900 capitalize tracking-tight flex items-center gap-2">
            {currentView === 'PROJECTS' && <LayoutGrid className="text-slate-400" size={24} />}
            {currentView === 'TASKS' && <CheckSquare className="text-slate-400" size={24} />}
            {currentView === 'AGENTS' && <Users className="text-slate-400" size={24} />}
            {currentView.toLowerCase()}
          </h2>
          <span className="text-xs font-mono font-medium text-slate-500 bg-white px-3 py-1.5 rounded-lg border border-slate-200 shadow-sm">
            Total {currentView === 'PROJECTS' ? projects.length : (currentView === 'TASKS' ? tasks.length : agents.length)}
          </span>
        </div>

        <div className="animate-slide-up min-h-[50vh]">
          {currentView === 'PROJECTS' && (
            <ProjectList projects={projects} onSelect={setSelectedProject} />
          )}
          {currentView === 'TASKS' && (
            <TaskList tasks={tasks} onSelect={setSelectedTask} />
          )}
          {currentView === 'AGENTS' && (
            <AgentList agents={agents} onSelect={setSelectedAgent} />
          )}
        </div>
      </main>

      {/* Floating Bottom Nav */}
      <nav className="fixed bottom-8 left-1/2 -translate-x-1/2 bg-slate-900/90 backdrop-blur-xl border border-white/10 rounded-2xl px-2 py-2 shadow-2xl shadow-slate-900/30 z-50 flex items-center gap-2">
          {['PROJECTS', 'TASKS', 'AGENTS'].map((view) => (
            <button 
              key={view}
              onClick={() => setCurrentView(view as View)}
              className={`px-5 py-3 rounded-xl flex flex-col items-center gap-1 transition-all duration-300 relative group ${currentView === view ? 'bg-white/10 text-white shadow-inner' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}
            >
              {view === 'PROJECTS' && <LayoutGrid size={20} />}
              {view === 'TASKS' && <CheckSquare size={20} />}
              {view === 'AGENTS' && <Users size={20} />}
              <span className="text-[9px] font-bold tracking-widest opacity-0 group-hover:opacity-100 absolute -top-8 bg-slate-900 text-white px-2 py-1 rounded border border-white/10 transition-opacity whitespace-nowrap pointer-events-none">
                {view}
              </span>
            </button>
          ))}
      </nav>

      {/* --- MODALS --- */}

      {/* Project Modal */}
      <Modal 
        isOpen={!!selectedProject} 
        onClose={closeModal} 
        title={selectedProject?.title || ''}
        actions={
          <button 
            onClick={() => selectedProject && handleGenerateReport('project', selectedProject)}
            disabled={aiLoading}
            className="w-full py-3.5 bg-slate-900 hover:bg-slate-800 rounded-xl font-medium text-white shadow-lg shadow-slate-900/20 active:scale-[0.98] transition-all flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed group relative overflow-hidden"
          >
             <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent translate-x-[-100%] group-hover:animate-[shimmer_1s_infinite]"></div>
            {aiLoading ? (
              <span className="animate-spin rounded-full h-5 w-5 border-2 border-white/30 border-t-white"></span>
            ) : (
              <><Cpu size={18} /> Generate AI Status Report</>
            )}
          </button>
        }
      >
        {selectedProject && (
          <div className="space-y-8">
             {aiReport && (
              <div className="bg-gradient-to-br from-primary-50 to-indigo-50 p-5 rounded-2xl border border-primary-100 animate-fade-in relative overflow-hidden">
                <div className="absolute top-0 right-0 p-3 opacity-10">
                  <Cpu size={100} className="text-primary-600" />
                </div>
                <div className="flex items-center gap-2 text-primary-700 mb-2 font-bold text-xs uppercase tracking-wider relative z-10">
                  <Cpu size={14} /> AI Executive Summary
                </div>
                <p className="text-sm text-slate-700 leading-relaxed relative z-10 font-medium">{aiReport}</p>
              </div>
            )}

            <div>
              <h4 className="text-slate-400 text-[10px] uppercase font-bold tracking-widest mb-3">Project Overview</h4>
              <p className="text-slate-600 leading-relaxed font-medium">{selectedProject.description}</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-slate-50 border border-slate-100 rounded-xl">
                <div className="text-slate-400 text-xs font-medium mb-1">Lead Architect</div>
                <div className="text-slate-900 font-bold flex items-center gap-2">
                   <div className="w-5 h-5 rounded-full bg-slate-200 flex items-center justify-center text-[10px] text-slate-500 overflow-hidden">
                     {getAgentName(selectedProject.leadAgentId).charAt(0)}
                   </div>
                   {getAgentName(selectedProject.leadAgentId)}
                </div>
              </div>
              <div className="p-4 bg-slate-50 border border-slate-100 rounded-xl">
                <div className="text-slate-400 text-xs font-medium mb-1">Budget Allocation</div>
                <div className="text-slate-900 font-bold">{selectedProject.budget}</div>
              </div>
            </div>

            <div>
               <div className="flex items-center justify-between mb-4">
                <h4 className="text-slate-400 text-[10px] uppercase font-bold tracking-widest">Active Tasks</h4>
                <Badge variant="default">{tasks.filter(t => t.projectId === selectedProject.id).length} Tasks</Badge>
              </div>
              <div className="space-y-3">
                {tasks.filter(t => t.projectId === selectedProject.id).map(task => (
                  <div key={task.id} className="flex justify-between items-center p-4 bg-white rounded-xl border border-slate-100 shadow-sm hover:border-primary-200 transition-colors">
                    <span className="text-sm text-slate-700 font-medium">{task.title}</span>
                    <Badge variant={task.status === 'DONE' ? 'success' : 'default'}>{task.status}</Badge>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </Modal>

      {/* Task Modal with ARTIFACTS */}
      <Modal 
        isOpen={!!selectedTask} 
        onClose={closeModal} 
        title="Task Command"
        actions={
           <button 
            onClick={() => selectedTask && handleGenerateReport('task', selectedTask)}
            disabled={aiLoading}
            className="w-full py-3.5 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl font-semibold text-slate-900 shadow-sm active:scale-[0.98] transition-all flex items-center justify-center gap-2 disabled:opacity-50"
          >
             {aiLoading ? <span className="animate-spin h-5 w-5 border-2 border-slate-300 border-t-slate-800 rounded-full"/> : "Analyze Blockers"}
          </button>
        }
      >
        {selectedTask && (
          <div className="space-y-6">
            
            {/* Artifacts / Output Files Section (Mocked) */}
             <div className="bg-slate-900 rounded-xl p-4 text-white overflow-hidden relative">
               <div className="flex items-center justify-between mb-4 border-b border-white/10 pb-2">
                 <div className="flex items-center gap-2 text-xs font-mono text-emerald-400">
                    <Terminal size={14} />
                    <span>OUTPUT_STREAM</span>
                 </div>
                 <Badge variant="success" className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">Review Pending</Badge>
               </div>
               
               <div className="space-y-2">
                 {getArtifactsForTask(selectedTask).map((file, i) => (
                   <div key={i} className="flex items-center justify-between group p-2 hover:bg-white/5 rounded-lg transition-colors cursor-pointer">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-slate-800 rounded-lg text-slate-300">
                          <FileText size={16} />
                        </div>
                        <div>
                          <div className="text-sm font-medium text-slate-200">{file.name}</div>
                          <div className="text-[10px] text-slate-500 font-mono">{file.size} • {file.type}</div>
                        </div>
                      </div>
                      <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                         <button className="p-1.5 hover:bg-white/10 rounded"><Eye size={14} className="text-slate-300"/></button>
                         <button className="p-1.5 hover:bg-white/10 rounded"><Download size={14} className="text-primary-400"/></button>
                      </div>
                   </div>
                 ))}
               </div>
             </div>

             {aiReport && (
              <div className="bg-amber-50 p-5 rounded-2xl border border-amber-100 animate-fade-in">
                 <div className="flex items-center gap-2 text-amber-700 mb-2 font-bold text-xs uppercase tracking-wider">
                  <Activity size={14} /> Tactical Analysis
                </div>
                <p className="text-sm text-slate-700 leading-relaxed font-medium">{aiReport}</p>
              </div>
            )}

            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold text-slate-900 leading-tight">{selectedTask.title}</h2>
              <Badge variant="warning">{selectedTask.priority}</Badge>
            </div>
            
            <p className="text-slate-600 font-medium">{selectedTask.description}</p>

            <div className="grid grid-cols-2 gap-4 text-sm bg-slate-50 p-4 rounded-2xl border border-slate-100">
              <div className="flex flex-col gap-1.5">
                <span className="text-slate-400 text-xs uppercase font-bold tracking-wide">Operative</span>
                <span className="text-slate-900 font-semibold">{getAgentName(selectedTask.assignedAgentId)}</span>
              </div>
              <div className="flex flex-col gap-1.5">
                <span className="text-slate-400 text-xs uppercase font-bold tracking-wide">Deadline</span>
                <span className="text-slate-900 font-semibold">{selectedTask.deadline}</span>
              </div>
              <div className="col-span-2">
                 <span className="text-slate-400 text-xs uppercase font-bold tracking-wide">Compilation Progress</span>
                 <div className="flex items-center gap-3 mt-1.5">
                   <div className="flex-1 h-3 bg-slate-200 rounded-full overflow-hidden relative">
                     <div className="h-full bg-gradient-to-r from-slate-900 to-slate-700 rounded-full relative" style={{ width: `${selectedTask.progress}%` }}>
                        {selectedTask.status === 'IN_PROGRESS' && (
                           <div className="absolute inset-0 bg-white/20 animate-[progressIndeterminate_1s_infinite_linear]"></div>
                        )}
                     </div>
                   </div>
                   <span className="text-slate-900 font-bold text-xs font-mono">{selectedTask.progress}%</span>
                 </div>
              </div>
            </div>

            <div>
              <h4 className="text-slate-400 text-[10px] uppercase font-bold tracking-widest mb-4">Communication Log</h4>
              <div className="space-y-4">
                {selectedTask.comments.length > 0 ? selectedTask.comments.map(comment => (
                  <div key={comment.id} className="flex gap-3">
                     <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center shrink-0 border border-slate-200 text-xs font-bold text-slate-500">
                        {comment.author.charAt(0)}
                     </div>
                     <div className="bg-white p-3 rounded-r-xl rounded-bl-xl border border-slate-100 shadow-sm flex-1">
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-slate-900 text-xs font-bold">{comment.author}</span>
                          <span className="text-slate-400 text-[10px] font-mono">{comment.timestamp}</span>
                        </div>
                        <p className="text-sm text-slate-600 font-medium">{comment.text}</p>
                     </div>
                  </div>
                )) : (
                  <div className="text-center py-8 bg-slate-50 rounded-xl border border-dashed border-slate-200 text-slate-400 text-sm">
                    No active communications recorded.
                  </div>
                )}
                
                <div className="relative mt-4">
                   <input 
                    type="text" 
                    placeholder="Input directive..." 
                    className="w-full bg-white border border-slate-200 rounded-xl py-3.5 pl-4 pr-12 text-sm text-slate-900 focus:outline-none focus:border-primary-500 focus:ring-2 focus:ring-primary-100 placeholder-slate-400 transition-all shadow-sm"
                   />
                   <button className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-primary-600 hover:bg-primary-50 rounded-lg transition-colors">
                     <Send size={18} />
                   </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </Modal>

      {/* Agent Modal */}
      <Modal 
        isOpen={!!selectedAgent} 
        onClose={closeModal} 
        title="Agent Profile"
         actions={
          <button 
             onClick={() => selectedAgent && handleGenerateReport('agent', selectedAgent)}
            disabled={aiLoading}
            className="w-full py-3.5 bg-slate-900 hover:bg-slate-800 rounded-xl font-medium text-white shadow-lg shadow-slate-900/20 active:scale-[0.98] transition-all flex items-center justify-center gap-2 disabled:opacity-70"
          >
            {aiLoading ? <span className="animate-spin h-5 w-5 border-2 border-white/30 border-t-white rounded-full"/> : "Evaluate Performance"}
          </button>
        }
      >
        {selectedAgent && (
          <div className="space-y-8">
            <div className="flex items-center gap-5">
              <div className="relative">
                <img src={selectedAgent.avatar} alt={selectedAgent.name} className="w-24 h-24 rounded-2xl ring-4 ring-white shadow-lg object-cover bg-slate-200" />
                <div className={`absolute -bottom-2 -right-2 px-3 py-1 bg-white rounded-full shadow-md border border-slate-100 flex items-center gap-1.5`}>
                   <span className={`w-2 h-2 rounded-full ${selectedAgent.status === 'ONLINE' ? 'bg-emerald-500 animate-pulse' : 'bg-slate-300'}`}></span>
                   <span className="text-[10px] font-bold text-slate-700">{selectedAgent.status}</span>
                </div>
              </div>
              <div>
                <h3 className="text-2xl font-bold text-slate-900 tracking-tight">{selectedAgent.name}</h3>
                <p className="text-primary-600 font-semibold">{selectedAgent.role}</p>
                <div className="flex gap-2 mt-3">
                   <div className="px-2 py-1 bg-slate-100 rounded text-[10px] font-mono text-slate-500 uppercase">ID: {selectedAgent.id}</div>
                </div>
              </div>
            </div>

             {aiReport && (
              <div className="bg-primary-50 p-5 rounded-2xl border border-primary-100 animate-fade-in">
                 <div className="flex items-center gap-2 text-primary-700 mb-2 font-bold text-xs uppercase tracking-wider">
                  <Cpu size={14} /> Performance Review
                </div>
                <p className="text-sm text-slate-700 leading-relaxed font-medium">{aiReport}</p>
              </div>
            )}

            <div>
              <h4 className="text-slate-400 text-[10px] uppercase font-bold tracking-widest mb-3">Capabilities</h4>
              <div className="flex flex-wrap gap-2">
                {selectedAgent.skills.map(skill => (
                  <span key={skill} className="px-3 py-1.5 bg-white rounded-full text-xs font-medium text-slate-700 border border-slate-200 shadow-sm">{skill}</span>
                ))}
              </div>
            </div>

            <div>
              <h4 className="text-slate-400 text-[10px] uppercase font-bold tracking-widest mb-4">Live Activity Stream</h4>
              <div className="relative pl-4 space-y-6 border-l-2 border-slate-100 ml-2">
                {timeline.filter(e => e.agentId === selectedAgent.id).length > 0 ? timeline.filter(e => e.agentId === selectedAgent.id).map(event => (
                  <div key={event.id} className="relative group">
                    <div className="absolute -left-[23px] top-1.5 w-4 h-4 rounded-full bg-white border-4 border-slate-200 group-hover:border-primary-500 transition-colors" />
                    <div className="flex flex-col">
                      <span className="text-xs font-mono text-slate-400 mb-0.5">{event.timestamp.split(' ')[1]}</span>
                      <p className="text-sm text-slate-800 font-medium">{event.description}</p>
                      <span className="text-[10px] text-primary-600 font-bold uppercase mt-1 tracking-wide">{event.type}</span>
                    </div>
                  </div>
                )) : (
                   <div className="text-slate-400 text-sm italic pl-2">No recent activity recorded.</div>
                )}
              </div>
            </div>
          </div>
        )}
      </Modal>

    </div>
  );
};

export default App;