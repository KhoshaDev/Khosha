import React from 'react';

interface StatsCardProps {
  title: string;
  value: string | number;
  icon?: React.ReactNode;
  trend?: string;
  color?: 'blue' | 'green' | 'purple' | 'orange';
}

export const StatsCard: React.FC<StatsCardProps> = ({ title, value, icon, trend, color = 'blue' }) => {
  const styles = {
    blue:   { bg: 'from-blue-500/10 to-blue-600/5', border: 'border-blue-500/20', icon: 'text-blue-400', glow: 'shadow-[0_0_15px_rgba(59,130,246,0.15)]' },
    green:  { bg: 'from-emerald-500/10 to-emerald-600/5', border: 'border-emerald-500/20', icon: 'text-emerald-400', glow: 'shadow-[0_0_15px_rgba(16,185,129,0.15)]' },
    purple: { bg: 'from-violet-500/10 to-violet-600/5', border: 'border-violet-500/20', icon: 'text-violet-400', glow: 'shadow-[0_0_15px_rgba(139,92,246,0.15)]' },
    orange: { bg: 'from-amber-500/10 to-amber-600/5', border: 'border-amber-500/20', icon: 'text-amber-400', glow: 'shadow-[0_0_15px_rgba(245,158,11,0.15)]' },
  };

  const s = styles[color];

  return (
    <div className={`relative overflow-hidden rounded-2xl border ${s.border} bg-gradient-to-br ${s.bg} backdrop-blur-xl p-4 flex flex-col justify-between group hover:border-opacity-40 transition-all duration-300 ${s.glow}`}>
      <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:opacity-20 transition-opacity transform group-hover:scale-110 duration-500">
         {/* Large background icon effect */}
         <div className="scale-[2.5]">{icon}</div>
      </div>
      
      <div className="flex items-center gap-2 mb-1">
        <div className={`p-1.5 rounded-lg bg-white/5 ${s.icon}`}>
            {React.isValidElement(icon) ? React.cloneElement(icon as React.ReactElement<any>, { size: 14 }) : icon}
        </div>
        <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-widest">{title}</h3>
      </div>
      
      <div className="flex items-end gap-2 mt-1">
        <span className="text-xl font-bold text-gray-100 tracking-tight leading-none">{value}</span>
        {trend && <span className="text-[10px] font-medium text-gray-500 mb-0.5">{trend}</span>}
      </div>
    </div>
  );
};