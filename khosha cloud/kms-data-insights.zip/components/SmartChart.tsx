import React, { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { QueryResult } from '../types';

interface SmartChartProps {
  data: QueryResult;
  tableName: string;
}

// Neon/Bright colors for dark mode
const COLORS = ['#38bdf8', '#34d399', '#fbbf24', '#f87171', '#a78bfa', '#f472b6'];

export const SmartChart: React.FC<SmartChartProps> = ({ data, tableName }) => {
  const { processedData, chartType, dataKey, categoryKey } = useMemo(() => {
    if (!data.rows.length) return { processedData: [], chartType: 'none', dataKey: '', categoryKey: '' };

    const columns = data.columns;
    const sampleRow = data.rows[0];

    const numericCols = columns.filter(col => {
        const val = sampleRow[col];
        return typeof val === 'number' && !col.toLowerCase().endsWith('id');
    });

    const categoryCols = columns.filter(col => {
        const val = sampleRow[col];
        return typeof val === 'string' && val.length < 50;
    });

    const dateCols = columns.filter(col => {
        const val = sampleRow[col];
        const lower = col.toLowerCase();
        return (typeof val === 'string' || typeof val === 'number') && 
               (lower.includes('date') || lower.includes('time') || lower.includes('created'));
    });

    if (dateCols.length > 0 && numericCols.length > 0) {
        const dKey = dateCols[0];
        const vKey = numericCols[0];
        const sorted = [...data.rows].sort((a, b) => (new Date(a[dKey]).getTime() - new Date(b[dKey]).getTime())).slice(-20);
        return { processedData: sorted, chartType: 'line', categoryKey: dKey, dataKey: vKey };
    }

    if (categoryCols.length > 0 && numericCols.length > 0) {
        return { processedData: data.rows.slice(0, 10), chartType: 'bar', categoryKey: categoryCols[0], dataKey: numericCols[0] };
    }

    if (categoryCols.length > 0) {
        const catKey = categoryCols[0];
        const counts: Record<string, number> = {};
        data.rows.forEach(row => {
            const val = String(row[catKey]);
            counts[val] = (counts[val] || 0) + 1;
        });
        const pieData = Object.entries(counts)
            .map(([name, value]) => ({ name, value }))
            .sort((a, b) => b.value - a.value)
            .slice(0, 6);
        return { processedData: pieData, chartType: 'pie', categoryKey: 'name', dataKey: 'value' };
    }
    
    if (numericCols.length > 0) {
         return { processedData: data.rows.slice(0, 20), chartType: 'bar', categoryKey: 'id', dataKey: numericCols[0] };
    }

    return { processedData: [], chartType: 'none', dataKey: '', categoryKey: '' };
  }, [data]);

  if (chartType === 'none' || processedData.length === 0) {
    return (
        <div className="h-48 flex flex-col items-center justify-center bg-white/5 rounded-2xl border border-dashed border-white/10">
            <span className="text-gray-500 text-xs font-mono">NO TRENDS DETECTED</span>
        </div>
    );
  }

  // Common Tooltip Style
  const tooltipStyle = {
    backgroundColor: 'rgba(15, 23, 42, 0.9)',
    border: '1px solid rgba(255,255,255,0.1)',
    borderRadius: '8px',
    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.5)',
    color: '#f3f4f6',
    fontSize: '12px'
  };

  const renderChart = () => {
    switch (chartType) {
        case 'line':
            return (
                <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={processedData}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.05)" />
                        <XAxis 
                            dataKey={categoryKey} 
                            tick={{fontSize: 10, fill: '#94a3b8'}} 
                            tickFormatter={(val) => typeof val === 'string' ? val.substring(0, 10) : val}
                            stroke="transparent"
                            dy={10}
                        />
                        <YAxis tick={{fontSize: 10, fill: '#94a3b8'}} stroke="transparent" />
                        <Tooltip contentStyle={tooltipStyle} itemStyle={{color: '#38bdf8'}} cursor={{stroke: 'rgba(255,255,255,0.1)'}} />
                        <Line 
                            type="monotone" 
                            dataKey={dataKey} 
                            stroke="#38bdf8" 
                            strokeWidth={3} 
                            dot={false}
                            activeDot={{r: 6, fill: '#38bdf8', stroke: '#0f172a', strokeWidth: 2}} 
                        />
                    </LineChart>
                </ResponsiveContainer>
            );
        case 'bar':
            return (
                 <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={processedData} layout="vertical" margin={{left: 0, right: 0}}>
                         <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} stroke="rgba(255,255,255,0.05)" />
                        <XAxis type="number" hide />
                        <YAxis 
                            dataKey={categoryKey} 
                            type="category" 
                            width={70} 
                            tick={{fontSize: 10, fill: '#94a3b8'}} 
                            interval={0}
                            stroke="transparent"
                        />
                        <Tooltip contentStyle={tooltipStyle} cursor={{fill: 'rgba(255,255,255,0.05)'}} />
                        <Bar dataKey={dataKey} fill="#38bdf8" radius={[0, 4, 4, 0]} barSize={12} />
                    </BarChart>
                </ResponsiveContainer>
            );
        case 'pie':
             return (
                 <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                        <Pie
                            data={processedData}
                            cx="50%"
                            cy="50%"
                            innerRadius={50}
                            outerRadius={70}
                            paddingAngle={5}
                            dataKey="value"
                            stroke="none"
                        >
                            {processedData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                        </Pie>
                        <Tooltip contentStyle={tooltipStyle} />
                    </PieChart>
                </ResponsiveContainer>
            );
        default:
            return null;
    }
  };

  return (
    <div className="bg-gray-900/40 backdrop-blur-xl p-5 rounded-2xl shadow-lg border border-white/5 h-full flex flex-col">
      <h3 className="text-gray-400 font-bold mb-6 text-xs uppercase tracking-widest flex items-center justify-between">
        <span>Analysis</span>
        <span className="text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded text-[10px]">{tableName}</span>
      </h3>
      <div className="flex-1 min-h-[180px]">
        {renderChart()}
      </div>
      {chartType === 'pie' && (
        <div className="mt-4 flex flex-wrap gap-2 justify-center">
            {processedData.map((entry: any, index: number) => (
                <div key={index} className="flex items-center gap-1.5 bg-white/5 px-2 py-1 rounded-full border border-white/5">
                    <span className="w-1.5 h-1.5 rounded-full" style={{backgroundColor: COLORS[index % COLORS.length]}}></span>
                    <span className="text-[10px] text-gray-400">{entry.name}</span>
                </div>
            ))}
        </div>
      )}
    </div>
  );
};