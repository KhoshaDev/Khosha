import React, { useEffect, useState } from 'react';
import { dbService } from './services/db';
import { TableInfo, QueryResult } from './types';
import { StatsCard } from './components/StatsCard';
import { SmartChart } from './components/SmartChart';
import { 
  Database, 
  Activity, 
  Table as TableIcon, 
  RefreshCw, 
  AlertTriangle,
  TrendingUp,
  Layers,
  Search,
  MoreHorizontal
} from 'lucide-react';

const App: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [tables, setTables] = useState<TableInfo[]>([]);
  const [selectedTable, setSelectedTable] = useState<string | null>(null);
  const [tableData, setTableData] = useState<QueryResult | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  useEffect(() => {
    initApp();
  }, []);

  const initApp = async () => {
    setLoading(true);
    setError(null);
    try {
      const tablesList = await dbService.getTables();
      setTables(tablesList);
      if (tablesList.length > 0) {
        handleSelectTable(tablesList[0].name);
      } else {
        setLoading(false);
      }
    } catch (err: any) {
      console.error(err);
      setError("Unable to sync with KMS Database.");
      setLoading(false);
    }
  };

  const refreshData = async () => {
    if (!selectedTable) return;
    setIsRefreshing(true);
    await handleSelectTable(selectedTable);
    setTimeout(() => setIsRefreshing(false), 500);
  };

  const handleSelectTable = async (tableName: string) => {
    try {
      if (!isRefreshing) setLoading(true); // Don't show full loader on refresh
      setSelectedTable(tableName);
      const data = await dbService.getTableData(tableName, 50);
      setTableData(data);
    } catch (err) {
      console.error(err);
      setError(`Failed to load: ${tableName}`);
    } finally {
      setLoading(false);
    }
  };

  const totalRows = tables.reduce((acc, t) => acc + (t.rowCount || 0), 0);
  const largestTable = tables.length > 0 ? tables[0] : null;

  if (loading && !selectedTable && !error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#050505]">
        <div className="flex flex-col items-center gap-4">
            <div className="relative">
                <div className="absolute inset-0 bg-blue-500 blur-xl opacity-20 rounded-full"></div>
                <div className="animate-spin text-blue-500 relative z-10">
                    <RefreshCw size={48} strokeWidth={1.5} />
                </div>
            </div>
            <p className="text-gray-500 font-mono text-xs uppercase tracking-widest animate-pulse">Initializing Core...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#050505] text-gray-300 selection:bg-blue-500/30">
      
      {/* Background Ambient Glows */}
      <div className="fixed top-0 left-0 w-full h-96 bg-blue-900/10 blur-[100px] pointer-events-none" />
      <div className="fixed bottom-0 right-0 w-96 h-96 bg-purple-900/10 blur-[100px] pointer-events-none" />

      {/* Main Container */}
      <div className="max-w-[1600px] mx-auto p-4 md:p-6 lg:p-8 space-y-6 relative z-10">

        {/* Header Area */}
        <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
            <div className="flex items-center gap-4 group">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-blue-900/20 ring-1 ring-white/10 group-hover:rotate-12 transition-transform duration-500">
                    <Database size={24} />
                </div>
                <div>
                    <h1 className="text-2xl font-bold text-white tracking-tight leading-none">KMS Insights</h1>
                    <div className="flex items-center gap-2 mt-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                        <p className="text-xs text-gray-500 font-medium uppercase tracking-wider">Connected • AWS AP South 1</p>
                    </div>
                </div>
            </div>
            
            <button 
                onClick={refreshData} 
                className={`p-2.5 rounded-xl bg-gray-800/50 hover:bg-gray-800 text-gray-400 hover:text-white border border-gray-700/50 transition-all ${isRefreshing ? 'animate-spin' : ''}`}
                aria-label="Refresh"
            >
                <RefreshCw size={20} />
            </button>
        </header>

        {/* Horizontal Navigation Pills (Super Compact Table Selector) */}
        <div className="sticky top-2 z-50 -mx-4 px-4 md:mx-0 md:px-0">
             <div className="bg-gray-900/80 backdrop-blur-xl border border-white/5 p-2 rounded-2xl flex gap-2 overflow-x-auto no-scrollbar shadow-2xl">
                 <div className="flex items-center pl-2 pr-4 border-r border-white/10 mr-2">
                     <Search size={16} className="text-gray-500" />
                 </div>
                 {tables.map(table => (
                    <button
                        key={table.name}
                        onClick={() => handleSelectTable(table.name)}
                        className={`
                            whitespace-nowrap px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300 flex items-center gap-2
                            ${selectedTable === table.name 
                                ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20' 
                                : 'bg-gray-800/30 text-gray-400 hover:bg-gray-800 hover:text-gray-200'
                            }
                        `}
                    >
                        <span>{table.name}</span>
                        <span className={`text-[10px] px-1.5 py-0.5 rounded-md ${selectedTable === table.name ? 'bg-blue-500 text-blue-100' : 'bg-gray-800 text-gray-500'}`}>
                            {table.rowCount}
                        </span>
                    </button>
                 ))}
             </div>
        </div>

        {/* Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Left Column: Stats & Chart (Fixed Height on Desktop) */}
            <div className="lg:col-span-4 space-y-6 flex flex-col">
                
                {/* Stats Grid */}
                <div className="grid grid-cols-2 gap-3">
                    <StatsCard 
                        title="Tables" 
                        value={tables.length} 
                        icon={<Layers />}
                        color="blue"
                    />
                    <StatsCard 
                        title="Records" 
                        value={(totalRows / 1000).toFixed(1) + 'k'} 
                        icon={<Activity />}
                        color="green"
                    />
                    <StatsCard 
                        title="Top Source" 
                        value={largestTable?.rowCount || 0} 
                        trend={largestTable?.name.substring(0, 8) + '...'}
                        icon={<TrendingUp />}
                        color="purple"
                    />
                    <StatsCard 
                        title="DB Health" 
                        value="100%" 
                        icon={<Database />}
                        color="orange"
                    />
                </div>

                {/* Chart Area */}
                {selectedTable && tableData && (
                    <div className="flex-1 min-h-[300px]">
                        <SmartChart data={tableData} tableName={selectedTable} />
                    </div>
                )}
            </div>

            {/* Right Column: Main Data Table */}
            <div className="lg:col-span-8">
                <div className="bg-gray-900/40 backdrop-blur-xl border border-white/5 rounded-2xl overflow-hidden flex flex-col h-[600px] lg:h-full shadow-2xl">
                    {/* Table Header */}
                    <div className="px-6 py-4 border-b border-white/5 flex justify-between items-center bg-white/[0.02]">
                        <h3 className="font-semibold text-gray-200 flex items-center gap-2">
                            <TableIcon size={18} className="text-blue-500" /> 
                            {selectedTable}
                        </h3>
                        <div className="flex gap-2">
                             <button className="p-1.5 hover:bg-white/5 rounded-lg text-gray-500 transition"><MoreHorizontal size={16} /></button>
                        </div>
                    </div>
                    
                    {/* Table Content */}
                    <div className="flex-1 overflow-auto custom-scrollbar relative">
                        {loading && (
                            <div className="absolute inset-0 bg-gray-950/50 backdrop-blur-sm z-10 flex items-center justify-center">
                                <RefreshCw size={24} className="animate-spin text-blue-500" />
                            </div>
                        )}
                        
                        {tableData && tableData.rows.length > 0 ? (
                            <table className="w-full text-left border-collapse">
                                <thead className="sticky top-0 z-10 bg-[#0B0F19] shadow-sm">
                                    <tr>
                                        {tableData.columns.map((col) => (
                                            <th key={col} className="px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider whitespace-nowrap border-b border-white/5">
                                                {col}
                                            </th>
                                        ))}
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-white/5">
                                    {tableData.rows.map((row, idx) => (
                                        <tr key={idx} className="group hover:bg-white/[0.02] transition-colors">
                                            {tableData.columns.map((col, cIdx) => (
                                                <td key={`${idx}-${col}`} className={`px-6 py-3 text-sm whitespace-nowrap max-w-[200px] truncate ${cIdx === 0 ? 'font-mono text-blue-400' : 'text-gray-400 group-hover:text-gray-200'}`}>
                                                    {row[col] !== null ? String(row[col]) : <span className="text-gray-700 text-xs italic">null</span>}
                                                </td>
                                            ))}
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        ) : (
                            <div className="flex h-full flex-col items-center justify-center text-gray-600 gap-4">
                                <div className="p-4 rounded-full bg-gray-800/50"><TableIcon size={32} /></div>
                                <p className="text-sm">No data available for this view.</p>
                            </div>
                        )}
                    </div>
                    
                    {/* Table Footer */}
                    <div className="px-6 py-3 border-t border-white/5 bg-white/[0.02] flex justify-between items-center text-xs text-gray-500">
                        <span>Showing {tableData?.rows.length || 0} recent records</span>
                        <div className="flex gap-4">
                            <span>Read-only View</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {/* Connection Error State */}
        {error && (
            <div className="fixed bottom-6 right-6 z-50 animate-bounce">
                 <div className="bg-red-500/10 backdrop-blur-xl border border-red-500/20 text-red-400 px-6 py-4 rounded-xl shadow-2xl flex items-center gap-3">
                    <AlertTriangle size={20} />
                    <span className="font-medium">{error}</span>
                    <button onClick={initApp} className="ml-4 text-xs bg-red-500/20 hover:bg-red-500/30 px-3 py-1.5 rounded-lg transition-colors">Retry</button>
                 </div>
            </div>
        )}

      </div>
    </div>
  );
};

export default App;