import { createClient } from "@libsql/client/web";
import { TableInfo, ColumnInfo, QueryResult } from "../types";

// Configuration provided in the prompt
const DB_URL = "libsql://kms-khoshasystems.aws-ap-south-1.turso.io";
const AUTH_TOKEN = "eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.eyJhIjoicnciLCJpYXQiOjE3NzA3NTU5NjUsImlkIjoiMTM0MWZlMGYtYzUyNy00NTAyLTk3MzUtNmM1ZTQ1MWU0OThkIiwicmlkIjoiYjVhNTZjNjQtZDA1MS00Y2FiLWIzMDktNjRkN2RlZjMwZTE3In0.UCcK0EGQHj8StOL_DRlRcvNukqkdlOa4Pr1hJ5gDoGeRMkqlF1Sp0JVEya_PRAD052FYkLQxrnpPwMNICQEDCw";

const client = createClient({
  url: DB_URL,
  authToken: AUTH_TOKEN,
});

export const dbService = {
  /**
   * Test connection and get all table names
   */
  async getTables(): Promise<TableInfo[]> {
    try {
      const rs = await client.execute("SELECT name FROM sqlite_schema WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name NOT LIKE '_litestream_%'");
      const tables: TableInfo[] = rs.rows.map((row) => ({
        name: row.name as string,
      }));
      
      // Enrich with row counts (optional, but good for "best data points")
      for (const table of tables) {
        try {
            const countRs = await client.execute(`SELECT COUNT(*) as count FROM "${table.name}"`);
            table.rowCount = Number(countRs.rows[0].count);
        } catch (e) {
            console.warn(`Could not get count for table ${table.name}`, e);
            table.rowCount = 0;
        }
      }
      
      // Sort by row count to show most interesting tables first
      return tables.sort((a, b) => (b.rowCount || 0) - (a.rowCount || 0));
    } catch (error) {
      console.error("Error fetching tables:", error);
      throw error;
    }
  },

  /**
   * Get column information for a table (Pragma is restricted in some environments, so we use a limit 1 query if needed, but pragma is better)
   */
  async getTableSchema(tableName: string): Promise<ColumnInfo[]> {
    try {
      const rs = await client.execute(`PRAGMA table_info("${tableName}")`);
      return rs.rows.map((row) => ({
        name: row.name as string,
        type: row.type as string,
      }));
    } catch (e) {
      // Fallback: select 1 row to guess types if PRAGMA fails
      console.warn("PRAGMA failed, falling back to data inspection", e);
      return [];
    }
  },

  /**
   * Fetch data from a table with a limit
   */
  async getTableData(tableName: string, limit = 100): Promise<QueryResult> {
    try {
      const rs = await client.execute(`SELECT * FROM "${tableName}" LIMIT ${limit}`);
      return {
        columns: rs.columns,
        rows: rs.rows,
      };
    } catch (error) {
      console.error(`Error fetching data for ${tableName}:`, error);
      throw error;
    }
  },

  /**
   * Execute a raw query (for custom aggregation)
   */
  async executeQuery(query: string): Promise<QueryResult> {
    const rs = await client.execute(query);
    return {
        columns: rs.columns,
        rows: rs.rows,
    };
  }
};
