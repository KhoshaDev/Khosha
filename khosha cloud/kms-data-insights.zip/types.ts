export interface TableInfo {
  name: string;
  rowCount?: number;
}

export interface ColumnInfo {
  name: string;
  type: string;
}

export interface QueryResult {
  columns: string[];
  rows: any[];
}

export enum ViewMode {
  DASHBOARD = 'DASHBOARD',
  EXPLORER = 'EXPLORER',
}

export interface ChartDataPoint {
  name: string;
  value: number;
  [key: string]: any;
}
